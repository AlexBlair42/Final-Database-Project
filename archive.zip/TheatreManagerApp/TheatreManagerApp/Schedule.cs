﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheatreManagerApp
{
     public partial class Schedule : Form
     {
          public Schedule()
          {
               InitializeComponent();
          }

          private void Schedule_Load(object sender, EventArgs e)
          {

          }

          private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
          {

          }
     }
}
// Which method do we want to display the schedule for movies? I have three listed in the Schedule.cs file